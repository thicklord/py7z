import click



@click.command()
@click.argument("path",type=click.Path, help='Path to 7z file or directory for compression')
@click.option("--level", "-l", type=int, default=0, )
@click.option("--depth", "-d", type=click.Choice(["R", "S", "P"]), default="P")
@click.option("--remove", "-r", is_flag=False)
def compressor(path, level, depth, remove):
    
    squeezer(path, level, depth)


@click.command()
@click.argument("path", type=click.Path)
@click.option("--remove", "-r", is_flag=True, help='Triggers removal of archives after successful decompression')
@click.option("--include-extension", "-ie", "extensions", multiple=True)
def extractor(path, remove, extensions):
    
    extensions = list(extensions)

    master_blaster(path, extensions)
    
    
    
    pass


@click.command()
@click.argument("path", type=click.Path, help='Path to 7z file or directory for compression')
@click.option("--level", "-l", type=int, default=0,
              help='Level of compression for all objects to compress (0-9). Default = 0')
@click.option("--compression-mode", "-m", type=click.Choice(["R", "S", "P"]), default="P",
              help="Compress root argument, sub-directories in the root level, or all directories recursively")
@click.option("--delete-compressed", "-d", is_flag=False,
              help="Triggers removal of directories after successful compression")
def compressor(cpath, level, depth, removal):
    squeezer(cpath, level, depth, removal)