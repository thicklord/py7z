def prse():
	parser = ArgumentParser(
		description='Python script to pipe 7zip commands'
	)
	
	# path argument
	parser.add_argument(
		'path',
		# dest='path',
		help='Path to 7z file or directory for compression'
	)
	
	# sub-parsers to split compression and extraction
	subpz = parser.add_subparsers(
		help="7z mode. Extraction or Compression",
		dest='type',
	)
	
	cparse = subpz.add_parser('C')
	xparse = subpz.add_parser('X')
	
	# # extraction parser and arguments
	# flag to delete archives after extracting them
	xparse.add_argument(
		'-d',
		'--delete-archives',
		dest='remove',
		action='store_true',
		help='Triggers removal of archives after successful decompression'
	)
	
	# option to include other archive types other than 7z
	xparse.add_argument(
		'-i',
		'--include-type',
		dest='ext',
		help='Optional argument to include other archive formats'
	)
	
	# delete directories after compressed
	cparse.add_argument(
		'-d',
		'--delete-compressed',
		dest='remove',
		action='store_true',
		help='Triggers removal of directories after successful compression',
		default=None,
	)
	
	# compresssion level, between 0-9, default=0
	cparse.add_argument(
		'level',
		# '--compression-level',
		type=int,
		# action='store_true',
		default=0,
		# const=0,
		# nargs='?',
		help='Level of compression for all objects to compress (0-9). Default = 0',
		choices=range(0, 10),
	)
	
	# most level directory
	cparse.add_argument(
		'-m',
		'--compression-mode',
		dest='mode',
		# action='store_true',
		choices=['R', 'P', 'S'],
		default='P',
		type=str,
		# const='',
		# nargs='?',
		help="Compress root argument, sub-directories in the root level, or all directories recursively"
	
	)
	
	return parser.parse_args()