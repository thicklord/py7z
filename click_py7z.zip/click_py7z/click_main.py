import click
from tools.compression import *
from tools.extraction import *
from tools.functions import *


# @click.group()
# @click.command()
# @click.argument("path",
#                 "--path",
#                 help='Path to 7z file or directory for compression',
#                 )
# @click.argument("mode", type=click.Choice(["C", "X"]))
# @click.pass_context
# def main(ctx, path):
#
#
#
#     pass

# @click.group()


@click.group()
# @click.command()
# @click.argument("path", type=click.Path)
def cli():
	pass


@click.command()
@click.argument("path",
                # type=click.Path(exists=True),
                nargs=-1)
@click.option("--level", "-l", "level", type=click.IntRange(0,9), default=0,
              help='Level of compression for all objects to compress (0-9). Default = 0')
@click.option("--compression-mode", "-m", "depth", type=click.Choice(["R", "S", "P"]), default="P",
              help="Compress root argument, sub-directories in the root level, or all directories recursively")
@click.option("--delete-compressed", "-d", "removal", is_flag=True,
              help="Triggers removal of directories after successful compression")
def compress(path, level, depth, removal):
	squeezer(path, level, depth, removal)


@click.command()
@click.argument("path")
@click.option("--remove", "-r", is_flag=True, help='Triggers removal of archives after successful decompression')
@click.option("--include-extension", "-ie", "extensions", multiple=True, required=False)
def extract(path, remove, extensions):
	extensions = list(extensions)

	master_blaster(path, remove, extensions)

	pass


cli.add_command(compress)
cli.add_command(extract)



if __name__ == '__main__':
	cli()
	# compress()



