# from tools.info import *
from tools.info import *
from tools.functions import *


get_all_ftypes(oj("/Users/chris/Desktop/manual_tunez"))


